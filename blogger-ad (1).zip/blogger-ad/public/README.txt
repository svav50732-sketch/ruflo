Сюда положи озвучку: voice.mp3 (см. инструкцию в src/Main.tsx)
